package constant

var HashIDTable = []int{}
